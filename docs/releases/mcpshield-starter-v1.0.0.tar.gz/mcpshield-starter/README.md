# MCPShield Pro & Team Toolkit (`v1.0.0`)

**Deterministic OWASP MCP Top 10:2025 Security Scanner, Automatic Config Remediator, Cryptographic Lockfile Generator, and EU AI Act Annex IV Compliance Pack.**

Built by **Midas Labs** — 100% Offline Execution • Zero External Dependencies • Zero Telemetry.

---

## Quick Start (Requires Node.js >= 18)

```bash
# 1. Audit an MCP configuration file (Claude Desktop, Cursor, VS Code, or custom Agent Gateway)
node ./bin/mcpshield.mjs scan ./examples/vulnerable-mcp.json

# 2. Automatically remediate secrets, pin @latest packages, strip shell wrappers, and enforce Article 14/12 metadata
node ./bin/mcpshield.mjs fix ./examples/vulnerable-mcp.json --output ./hardened-mcp.json --env-out ./.env.example

# 3. Generate a cryptographic SHA-256 baseline lockfile to prevent MCP03/MCP04 rug-pull drift
node ./bin/mcpshield.mjs lock ./hardened-mcp.json --output ./mcp-lock.json

# 4. Export GitHub Code Scanning SARIF v2.1.0 report for CI/CD gates
node ./bin/mcpshield.mjs scan ./hardened-mcp.json --format sarif > mcpshield.sarif

# 5. Generate an Auditor-Ready EU AI Act Annex IV Technical Documentation Dossier
node ./bin/mcpshield.mjs annex4 ./hardened-mcp.json --org "Acme Technologies Ltd" --system "Customer Operations AI Agent" --output ./ANNEX_IV_DOSSIER.md

# 6. Generate a Board & CISO Executive Risk Register
node ./bin/mcpshield.mjs risk-register ./hardened-mcp.json --org "Acme Technologies Ltd" --output ./BOARD_RISK_REGISTER.md
```

## Included Compliance & Engineering Templates (`./templates/`)
1. `01-EU_AI_ACT_ANNEX_IV_DOSSIER.md`
2. `02-AI_RISK_MANAGEMENT_SYSTEM.md`
3. `03-MCP_SERVER_ALLOWLIST_POLICY.md`
4. `04-AI_INCIDENT_RESPONSE_PLAYBOOK.md`
5. `05-GDPR_AI_DPIA_TEMPLATE.md`
6. `06-VENDOR_MCP_SECURITY_QUESTIONNAIRE.md`
