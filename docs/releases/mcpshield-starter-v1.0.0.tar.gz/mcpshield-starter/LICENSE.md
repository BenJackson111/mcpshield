# MCPShield Commercial & Starter License Agreement

Copyright (c) 2026 Midas Labs. All rights reserved.

1. **Starter / Evaluation Tier:** The browser diagnostic utility and Starter sample pack may be used free of charge for evaluating MCP configurations.
2. **Pro Developer License (£49 One-Time):** Grants one (1) individual developer a perpetual, non-exclusive license to run the MCPShield CLI, remediation engine, SARIF exporter, and compliance templates across personal or commercial repositories.
3. **Team & Agency Audit License (£149 One-Time):** Grants an organization or consultancy an unlimited-seat perpetual license across internal repositories and client audit engagements, including white-label export of Annex IV Dossiers and Board Risk Registers.
4. **Disclaimer:** MCPShield provides deterministic technical security scanning and engineering documentation templates. It does not constitute formal legal representation or legal advice.
